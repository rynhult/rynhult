try { require("./lib/extra.js") } catch {}
